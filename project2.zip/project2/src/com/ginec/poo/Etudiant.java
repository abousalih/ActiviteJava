package com.ginec.poo;


public class Etudiant {
    private long id;
    private String nom;
    private String prenom;
}

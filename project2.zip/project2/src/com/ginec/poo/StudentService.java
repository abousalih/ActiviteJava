package com.ginec.poo;

import java.util.List;

public interface StudentService {
    void addEtudiant1(Etudiant etudiant);
    void updateEtudiant1(Etudiant etudiant);
    void deleteEtudiant1(long id);
    Etudiant getEtudiantById1(long id);
    List<Etudiant> getAllEtudiants1();
    List<Etudiant> getEtudiantsByCritere1(String critere);
    List<Etudiant> getEtudiantsByCritere2(String critere);
}

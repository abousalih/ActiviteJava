package com.ginec.poo;

import java.util.Date;

public class Voiture extends Vehicule{

    private int nbrPlace;

    public Voiture(String marque, Date dateSortie, double prix, double vitesseMax,int nbrPlace){
        super(marque,dateSortie,prix,vitesseMax);// Je fait appel au constructor de la class mere Vehicule
        this.nbrPlace = nbrPlace;
    }

    public Voiture(){}

    // Une Voiture est un Vehicule ==> Voiture est une specialisation (Extenssion) de Vehicule
    // C'est a dire Vehicule (Classe mère) et Voiture (Classe fille)
    // On dit que Voiture Hérite (extends) de Vehicule

    public void reduirePrix(){
        this.setPrix(this.getPrix()-this.getPrix()*0.05);
        //this.vitesse=120;
    }

    // La surcharge de la methode somme()

    public int somme(int a,int b,int c){
        return 2*(a+b);
    }

    @Override
    public String toString() {
        return "Voiture{" +  super.toString() +
                ", nbrPlace=" + nbrPlace +
                "} " ;
    }
}

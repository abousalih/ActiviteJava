package com.ginec.poo;

import java.util.List;

public interface EtudiantService {
    void addEtudiant(Etudiant etudiant);
    void updateEtudiant(Etudiant etudiant);
    void deleteEtudiant(long id);
    Etudiant getEtudiantById(long id);
    List<Etudiant> getAllEtudiants();
    List<Etudiant> getEtudiantsByCritere(String critere);
}

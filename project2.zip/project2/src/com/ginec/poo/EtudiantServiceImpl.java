package com.ginec.poo;

import java.util.List;

public class EtudiantServiceImpl implements EtudiantService,StudentService {
    @Override
    public void addEtudiant(Etudiant etudiant) {

    }

    @Override
    public void updateEtudiant(Etudiant etudiant) {

    }

    @Override
    public void deleteEtudiant(long id) {

    }

    @Override
    public Etudiant getEtudiantById(long id) {
        return null;
    }

    @Override
    public List<Etudiant> getAllEtudiants() {
        return null;
    }

    @Override
    public List<Etudiant> getEtudiantsByCritere(String critere) {
        return null;
    }

    @Override
    public void addEtudiant1(Etudiant etudiant) {

    }

    @Override
    public void updateEtudiant1(Etudiant etudiant) {

    }

    @Override
    public void deleteEtudiant1(long id) {

    }

    @Override
    public Etudiant getEtudiantById1(long id) {
        return null;
    }

    @Override
    public List<Etudiant> getAllEtudiants1() {
        return null;
    }

    @Override
    public List<Etudiant> getEtudiantsByCritere1(String critere) {
        return null;
    }

    @Override
    public List<Etudiant> getEtudiantsByCritere2(String critere) {
        return null;
    }
}

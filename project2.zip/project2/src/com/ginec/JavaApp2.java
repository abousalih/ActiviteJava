package com.ginec;

public class JavaApp2 {
    public static void main(String[] args) {
        /*
            Les Variables:
                Les Nombres : int, long, double, float (Type premitif)
                              Integer, Long, Double   (Classes)
                Text : String
                Date : Date
                Logique : boolean
         */

        int n1;
        double n2;
        int s;

        n1=10;
        n2=20.5;
        s= (int) (n1+n2);// Casting n1+n2 =30.5 (double==>(int)==>partie entiere (30)
        System.out.println(s);

    }
}

package com.ginec.activite1;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class Cargaison {
    private int distance;
    private List<Marchandise> marchandises;

    public Cargaison() {
    }

    public Cargaison(int distance) {
        this.distance=distance;
        this.marchandises=new ArrayList<>();
    }

    public Cargaison(int distance, List<Marchandise> marchandises) {
        this.distance = distance;
        this.marchandises = marchandises;
    }

    @Override
    public String toString() {
        return "Cargaison{" +
                "distance=" + distance  +'}';
    }

    public int getDistance() {
        return distance;
    }

    public void setDistance(int distance) {
        this.distance = distance;
    }

    public List<Marchandise> getMarchandises() {
        return marchandises;
    }

    public void setMarchandises(List<Marchandise> marchandises) {
        this.marchandises = marchandises;
    }

    void ajouterMarchandise(Marchandise m){
        this.marchandises.add(m);
    }

    void ajouterLesMarchandises(List<Marchandise> lesMarchandises){
        this.marchandises.addAll(lesMarchandises);
    }

    void afficherLesMarchandises(){
        this.marchandises.forEach(m ->
                {
                    System.out.println("Nom    :"+m.getNom());
                    System.out.println("Poids  :"+m.getPoids());
                    System.out.println("Volume :"+m.getVolume());
                    System.out.println("****************");
                }
        );
    }
}

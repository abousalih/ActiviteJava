package com.ginec.activite1;

import java.util.ArrayList;
import java.util.Collection;

public class appCargaison {
    public static void main(String[] args) {
        Marchandise m1 = new Marchandise(1, "Oranges", 300, 110);
        Marchandise m2 = new Marchandise(2, "Olives", 100, 50);
        Marchandise m3 = new Marchandise(3, "Tomates", 50, 20);

        Cargaison c1 = new Cargaison(200);

        c1.getMarchandises().add(m1);
        c1.getMarchandises().add(m2);
        c1.getMarchandises().add(m3);

       /* c1.ajouterMarchandise(m1);
        c1.ajouterMarchandise(m2);
        c1.ajouterMarchandise(m3);*/

        /*Collection<Marchandise> lesM = new ArrayList<Marchandise>();
        lesM.add(m1);
        lesM.add(m2);
        lesM.add(m3);
        c1.ajouterLesMarchandises(lesM);*/

        //System.out.println(c1.getMarchandises());
       /*
        for (int i = 0; i < c1.getMarchandises().size(); i++) {
            System.out.println(c1.getMarchandises().get(i).getNom()); // Afficher le nom de la mse N° i
        }
*/
        c1.afficherLesMarchandises();

        Cargaison c2 = new Cargaison(200);

        c2.getMarchandises().add(m1);
        c2.getMarchandises().add(m2);
        c2.getMarchandises().add(m3);

        c2.afficherLesMarchandises();

    }
}

package com.ginec.activite1;

public class CargaisonAerienne extends Cargaison {
    @Override
    public String toString() {
        return "Cargaison aerienne :"+getDistance();
    }
}

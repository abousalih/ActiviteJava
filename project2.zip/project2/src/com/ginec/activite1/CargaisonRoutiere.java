package com.ginec.activite1;

public class CargaisonRoutiere extends Cargaison{

    @Override
    public String toString() {
        return "Cargaison routière :"+getDistance();
    }
}

package com.ginec.activite1;

public class Marchandise {
    private int numero;
    private String nom;
    private int poids;
    private int volume;
    //private Cargaison cargaison;

    @Override
    public String toString() {
        return "Marchandise{" +
                "numero=" + numero +
                ", nom='" + nom + '\'' +
                ", poids=" + poids +
                ", volume=" + volume +'}';
    }

    public Marchandise() {
    }

    public Marchandise(int numero, String nom, int poids, int volume) {
        this.numero = numero;
        this.nom = nom;
        this.poids = poids;
        this.volume = volume;
    }

    public Marchandise(int numero, String nom, int poids, int volume, Cargaison cargaison) {
        this.numero = numero;
        this.nom = nom;
        this.poids = poids;
        this.volume = volume;
        //this.cargaison = cargaison;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public int getPoids() {
        return poids;
    }

    public void setPoids(int poids) {
        this.poids = poids;
    }

    public int getVolume() {
        return volume;
    }

    public void setVolume(int volume) {
        this.volume = volume;
    }
}

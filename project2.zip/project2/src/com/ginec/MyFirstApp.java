package com.ginec;

import com.ginec.poo.Vehicule;

import java.util.Scanner;

public class MyFirstApp {

    public static void main(String[] args) {
	// write your code here

        System.out.println("Hello, it's my first Java App");
        Scanner scanner = new Scanner(System.in);

        Vehicule v=new Vehicule();
        System.out.println("Quelle le nombre de place de la voiture?");
        //v.nbrPlace=scanner.nextInt();
       // System.out.println(v.nbrPlace);

        //v.vitesse=60;

        System.out.println("********** Vitesse avant ********");
        //System.out.println(v.vitesse);

        v.accelere();

        System.out.println("********** Vitesse apres ********");
       // System.out.println(v.vitesse);

    }
}

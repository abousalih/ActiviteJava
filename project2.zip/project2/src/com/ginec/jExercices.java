package com.ginec;

public class jExercices {


    public static void main(String[] args) {

        int x = 14;

        if (x >= 16) {
            System.out.println("T Bien");
        } else if (x >= 14) {
            System.out.println("Bien");
        } else {
            System.out.println("A Bien");
        }

        switch (x) {
            case 16:
                System.out.println("T Bien");
                break;
            case 14:
                System.out.println("Bien");
                break;
            case 13:
                System.out.println("A Bien");
                break;
            case 12:
                System.out.println("Pass");
                break;
            default:
                System.out.println("T Bien");
                break;
        }

        System.out.println("EX1");
        for (int i = 1; i <= 10; i++) {
            System.out.print("*");
        }

        System.out.println();
        System.out.println("EX2");
        for (int j = 1; j <= 5; j++) {
            for (int i = 1; i <= 10; i++) {
                System.out.print("*");
            }
            System.out.println();
        }

        System.out.println("EX3");
        for (int j = 1; j <= 5; j++) {
            for (int i = 1; i <= j; i++) {
                System.out.print("*");
            }
            System.out.println();
        }

        System.out.println("EX4");
        for (int j = 1; j <= 5; j++) {
            for (int i = 5; i >= j; i--) {
                System.out.print("*");
            }
            System.out.println();
        }
    }


    /*
        EX 1
            Un programme qui permet d'afficher :
            **********
        EX 2
            Un programme qui permet d'afficher :
            **********
            **********
            **********
            **********
            **********

        pour j=1 ===> ********** i=1 -----> 10
        pour j=2 ===> ********** i=1 -----> 10
        pour j=3 ===> ********** i=1 -----> 10
        pour j=4 ===> ********** i=1 -----> 10
        pour j=5 ===> ********** i=1 -----> 10


        Ex 3
        pour j=1 ===> *         i=1 -----> 1
        pour j=2 ===> **        i=1 -----> 2
        pour j=3 ===> ***       i=1 -----> 3
        pour j=4 ===> ****      i=1 -----> 4
        pour j=5 ===> *****     i=1 -----> 5


            *
            **
            ***
            ****
            *****
       Ex 4
            *****
            ****
            ***
            **
            *
     */
}

package com.ginec;


import java.util.Scanner;
public class jFunction {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int x, y, z,t;
        System.out.println("Enter four numbers");

        x = scanner.nextInt();
        y = scanner.nextInt();
        z = scanner.nextInt();
        t = scanner.nextInt();

        /*if (x > y && x>z) {
            System.out.println("The height is x="+x);
        } else if(y>x && y>z)  {
            System.out.println("The height is y="+y);
        }else if(z>x && z>y){
            System.out.println("The height is z="+z);
        }*/

        System.out.println("The height is :" + maxi(maxi(maxi(x,y),z),t));

        System.out.println("The height is :" + maxi(maxi(x,y),maxi(z,t)));
    }

    static int maxi(int x, int y) {
        if (x > y) {
            return x;
        } else {
            return y;
        }
    }



    // x     y    z
    // maxi(x,y)--->n1
    //maxi(n1,z)--->resultat
    //maxi(maxi(x,y),z)--->resultat


    // Function sum
    // Function avg
    // resultat : Adimis if avg>=10 else Non Admis
}
